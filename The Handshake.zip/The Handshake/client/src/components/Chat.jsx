import React from "react";

const Chat = (props) =>{


    return(
        <>
            <h1>{props.message}</h1>
        </>
    );
}

export default Chat;